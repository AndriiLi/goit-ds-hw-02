
DATABASE = 'postgres'
USER = 'postgres'
PASSWORD = 'password'
PORT = 5432
HOST = 'postgres'